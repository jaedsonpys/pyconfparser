from .main import PyConfigParser

__version__ = '0.1.0'
__author__ = 'Jaedson Silva'