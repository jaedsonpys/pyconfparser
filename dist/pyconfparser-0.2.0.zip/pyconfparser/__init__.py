from .main import PyConfigParser

__version__ = '0.2.0'
__author__ = 'Jaedson Silva'